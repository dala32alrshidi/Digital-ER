const express = require('express');
const bodyParser = require('body-parser');
const fetch = require('node-fetch');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

app.use(bodyParser.json());
app.use(express.static('public'));

app.post('/api/ask', async (req, res) => {
    const prompt = req.body.prompt;
    if (!prompt) return res.json({ answer: "يرجى إدخال السؤال / Please enter a question." });

    try {
        const response = await fetch('https://api.openai.com/v1/chat/completions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`
            },
            body: JSON.stringify({
                model: "gpt-4",
                messages: [{ role: "user", content: prompt }],
                temperature: 0.7,
                max_tokens: 500
            })
        });

        const data = await response.json();
        const answer = data.choices[0].message.content;
        res.json({ answer });
    } catch (err) {
        console.error(err);
        res.json({ answer: "حدث خطأ أثناء الاتصال بالـ AI / Error connecting to AI." });
    }
});

app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
